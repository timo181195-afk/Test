@echo off
java -jar KalanderTrackerLive_v3.jar
pause
