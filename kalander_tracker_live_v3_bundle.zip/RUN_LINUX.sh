#!/usr/bin/env bash
set -e
java -jar KalanderTrackerLive_v3.jar
