package com.kalandertracker;

import com.kalandertracker.Models.*;

public class Metrics {
    public static double planEndMeters(ShiftData sd) {
        double m = 0.0;
        for (PlanItem p : sd.plan) {
            if (p.type == PlanType.PRODUCE) {
                m += p.meters;
            }
        }
        return m;
    }

    public static double istEndMeters(ShiftData sd) {
        if (sd.ist.isEmpty()) return 0.0;
        return sd.ist.get(sd.ist.size() - 1).meterCumulative;
    }

    public static long totalDowntimeMinutes(ShiftData sd) {
        long sum = 0;
        for (Downtime d : sd.downtimes) {
            sum += downtimeMinutes(d);
        }
        return sum;
    }

    public static long downtimeMinutes(Downtime d) {
        if (d == null) return 0;
        long end = d.endEpochMs > 0 ? d.endEpochMs : System.currentTimeMillis();
        long diffMs = Math.max(0, end - d.startEpochMs);
        return diffMs / 60000;
    }
}
