package com.kalandertracker;

import com.kalandertracker.Models.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataStore {
    private final Path baseDir;

    public DataStore(Path baseDir) {
        this.baseDir = baseDir;
    }

    public DayData loadDay(LocalDate date) throws IOException {
        Files.createDirectories(baseDir);
        Path f = dayFile(date);
        if (!Files.exists(f)) {
            return new DayData();
        }
        try (BufferedReader br = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            return parse(br);
        }
    }

    public void saveDay(LocalDate date, DayData day) throws IOException {
        Files.createDirectories(baseDir);
        Path f = dayFile(date);
        try (BufferedWriter bw = Files.newBufferedWriter(f, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
            write(bw, day);
        }
    }

    public List<Path> exportDayCsv(LocalDate date, Path outDir) throws IOException {
        Files.createDirectories(outDir);
        DayData day = loadDay(date);
        List<Path> out = new ArrayList<>();
        for (Shift s : Shift.values()) {
            ShiftData sd = day.forShift(s);
            Path plan = outDir.resolve(date + "_" + s.name().toLowerCase() + "_plan.csv");
            Path ist = outDir.resolve(date + "_" + s.name().toLowerCase() + "_ist.csv");
            Path dt = outDir.resolve(date + "_" + s.name().toLowerCase() + "_stillstand.csv");

            try (BufferedWriter bw = Files.newBufferedWriter(plan, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                bw.write("type,meters,speed_mpm,duration_min,reason\n");
                for (PlanItem p : sd.plan) {
                    bw.write(p.type + "," + p.meters + "," + p.speedMpm + "," + p.durationMin + "," + csvEscape(p.downtimeReason) + "\n");
                }
            }
            try (BufferedWriter bw = Files.newBufferedWriter(ist, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                bw.write("timestamp_epoch_ms,meter_cumulative\n");
                for (IstReading r : sd.ist) {
                    bw.write(r.timestampEpochMs + "," + r.meterCumulative + "\n");
                }
            }
            try (BufferedWriter bw = Files.newBufferedWriter(dt, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                bw.write("start_epoch_ms,end_epoch_ms,reason,description\n");
                for (Downtime d : sd.downtimes) {
                    bw.write(d.startEpochMs + "," + d.endEpochMs + "," + csvEscape(d.reason) + "," + csvEscape(d.description) + "\n");
                }
            }
            out.add(plan);
            out.add(ist);
            out.add(dt);
        }
        return out;
    }

    private static String csvEscape(String s) {
        if (s == null) return "";
        String t = s.replace("\"", "\"\"");
        if (t.contains(",") || t.contains("\n") || t.contains("\r")) {
            return "\"" + t + "\"";
        }
        return t;
    }

    private Path dayFile(LocalDate date) {
        return baseDir.resolve(date + ".day");
    }

    // --- Custom file format (very simple)
    private DayData parse(BufferedReader br) throws IOException {
        DayData day = new DayData();
        Shift currentShift = null;
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (line.startsWith("SHIFT=")) {
                currentShift = Shift.valueOf(line.substring("SHIFT=".length()));
                continue;
            }
            if (line.startsWith("BASELINE=")) {
                // BASELINE=epochMs;meters
                if (currentShift == null) continue;
                String[] parts = line.substring("BASELINE=".length()).split(";", -1);
                ShiftData sd = day.forShift(currentShift);
                sd.baselineTimeEpochMs = Long.parseLong(parts[0]);
                sd.baselineMeters = Double.parseDouble(parts[1]);
                continue;
            }
            if (line.startsWith("PLAN=")) {
                if (currentShift == null) continue;
                // PLAN=type;meters;speed;duration;reason
                String[] p = line.substring("PLAN=".length()).split(";", -1);
                PlanItem item = new PlanItem();
                item.type = PlanType.valueOf(p[0]);
                item.meters = Double.parseDouble(p[1]);
                item.speedMpm = Double.parseDouble(p[2]);
                item.durationMin = Long.parseLong(p[3]);
                item.downtimeReason = unescape(p[4]);
                day.forShift(currentShift).plan.add(item);
                continue;
            }
            if (line.startsWith("IST=")) {
                if (currentShift == null) continue;
                // IST=epochMs;meters
                String[] p = line.substring("IST=".length()).split(";", -1);
                day.forShift(currentShift).ist.add(new IstReading(Long.parseLong(p[0]), Double.parseDouble(p[1])));
                continue;
            }
            if (line.startsWith("DT=")) {
                if (currentShift == null) continue;
                // DT=start;end;reason;description
                String[] p = line.substring("DT=".length()).split(";", -1);
                Downtime d = new Downtime(Long.parseLong(p[0]), unescape(p[2]), unescape(p[3]));
                d.endEpochMs = Long.parseLong(p[1]);
                day.forShift(currentShift).downtimes.add(d);
            }
        }
        return day;
    }

    private void write(BufferedWriter bw, DayData day) throws IOException {
        bw.write("# KalanderTracker Day File\n");
        for (Shift s : Shift.values()) {
            ShiftData sd = day.forShift(s);
            bw.write("SHIFT=" + s.name() + "\n");
            bw.write("BASELINE=" + sd.baselineTimeEpochMs + ";" + sd.baselineMeters + "\n");
            for (PlanItem p : sd.plan) {
                bw.write("PLAN=" + p.type + ";" + p.meters + ";" + p.speedMpm + ";" + p.durationMin + ";" + escape(p.downtimeReason) + "\n");
            }
            for (IstReading r : sd.ist) {
                bw.write("IST=" + r.timestampEpochMs + ";" + r.meterCumulative + "\n");
            }
            for (Downtime d : sd.downtimes) {
                bw.write("DT=" + d.startEpochMs + ";" + d.endEpochMs + ";" + escape(d.reason) + ";" + escape(d.description) + "\n");
            }
            bw.write("\n");
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace(";", "\\;").replace("\n", "\\n").replace("\r", "");
    }

    private static String unescape(String s) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder();
        boolean esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc) {
                if (c == 'n') out.append('\n');
                else out.append(c);
                esc = false;
            } else {
                if (c == '\\') esc = true;
                else out.append(c);
            }
        }
        return out.toString();
    }
}
