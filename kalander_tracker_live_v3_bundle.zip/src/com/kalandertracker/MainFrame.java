package com.kalandertracker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private final DataStore dataStore;
    private final DateComboModel dateModel;
    private final JComboBox<LocalDate> dateCombo;

    private final ShiftTab shiftEarly;
    private final ShiftTab shiftLate;
    private final ShiftTab shiftNight;

    public MainFrame() {
        super("Kalander Soll/Ist Tracker");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1250, 800);
        setLocationRelativeTo(null);

        Path baseDir = Path.of("data");
        this.dataStore = new DataStore(baseDir);

        // Date range: from 11.02.2026 forward 6 months by default (can be adjusted)
        LocalDate start = LocalDate.of(2026, 2, 11);
        LocalDate end = start.plusMonths(6);
        this.dateModel = new DateComboModel(start, end);
        this.dateCombo = new JComboBox<>(dateModel);
        this.dateCombo.setRenderer((list, value, index, isSelected, cellHasFocus) -> {
            JLabel lbl = new JLabel(value == null ? "" : value.format(DATE_FMT));
            lbl.setOpaque(true);
            if (isSelected) {
                lbl.setBackground(list.getSelectionBackground());
                lbl.setForeground(list.getSelectionForeground());
            } else {
                lbl.setBackground(list.getBackground());
                lbl.setForeground(list.getForeground());
            }
            return lbl;
        });

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.add(new JLabel("Datum:"));
        topBar.add(dateCombo);
        JButton openDataFolder = new JButton("Datenordner öffnen");
        openDataFolder.addActionListener(e -> openDataFolder());
        topBar.add(openDataFolder);

        setJMenuBar(buildMenuBar());

        JTabbedPane shiftTabs = new JTabbedPane();
        shiftEarly = new ShiftTab(Shift.EARLY, dataStore);
        shiftLate = new ShiftTab(Shift.LATE, dataStore);
        shiftNight = new ShiftTab(Shift.NIGHT, dataStore);

        shiftTabs.addTab("Früh (06–14)", shiftEarly);
        shiftTabs.addTab("Spät (14–22)", shiftLate);
        shiftTabs.addTab("Nacht (22–06)", shiftNight);

        setLayout(new BorderLayout());
        add(topBar, BorderLayout.NORTH);
        add(shiftTabs, BorderLayout.CENTER);

        dateCombo.addActionListener(e -> loadSelectedDate());
        dateCombo.setSelectedIndex(0);
        loadSelectedDate();
    }

    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();

        JMenu file = new JMenu("Datei");
        file.add(new AbstractAction("PDF Export (aktuelles Datum)") {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportPdf();
            }
        });
        file.add(new AbstractAction("CSV Export (aktuelles Datum)") {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportCsv();
            }
        });
        file.addSeparator();
        file.add(new AbstractAction("Datumsbereich einstellen…") {
            @Override
            public void actionPerformed(ActionEvent e) {
                configureDateRange();
            }
        });
        file.addSeparator();
        file.add(new AbstractAction("Beenden") {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        bar.add(file);
        return bar;
    }

    private LocalDate getSelectedDate() {
        LocalDate d = (LocalDate) dateCombo.getSelectedItem();
        return d == null ? LocalDate.of(2026, 2, 11) : d;
    }

    private void loadSelectedDate() {
        LocalDate date = getSelectedDate();
        shiftEarly.load(date);
        shiftLate.load(date);
        shiftNight.load(date);
    }

    private void exportPdf() {
        LocalDate date = getSelectedDate();
        try {
            Path outDir = Path.of("exports");
            Files.createDirectories(outDir);
            Path out = outDir.resolve("Report_" + date + ".pdf");

            Models.DayData day = dataStore.loadDay(date);
            PDFExporter.exportDayReport(out, date, day);
            JOptionPane.showMessageDialog(this, "PDF exportiert: " + out.toAbsolutePath(), "Export", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "PDF Export fehlgeschlagen: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportCsv() {
        LocalDate date = getSelectedDate();
        try {
            Path outDir = Path.of("exports");
            Files.createDirectories(outDir);
            List<Path> paths = dataStore.exportDayCsv(date, outDir);
            JOptionPane.showMessageDialog(this, "CSV exportiert:\n" + String.join("\n", paths.stream().map(p -> p.toAbsolutePath().toString()).toList()), "Export", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "CSV Export fehlgeschlagen: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void configureDateRange() {
        LocalDate currentStart = dateModel.getStart();
        LocalDate currentEnd = dateModel.getEnd();

        JTextField start = new JTextField(currentStart.toString());
        JTextField end = new JTextField(currentEnd.toString());
        JPanel p = new JPanel(new GridLayout(0, 1));
        p.add(new JLabel("Startdatum (YYYY-MM-DD):"));
        p.add(start);
        p.add(new JLabel("Enddatum (YYYY-MM-DD):"));
        p.add(end);

        int res = JOptionPane.showConfirmDialog(this, p, "Datumsbereich", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            LocalDate s = LocalDate.parse(start.getText().trim());
            LocalDate e = LocalDate.parse(end.getText().trim());
            if (e.isBefore(s)) throw new IllegalArgumentException("Ende vor Start");
            dateModel.setRange(s, e);
            dateCombo.setSelectedIndex(0);
            loadSelectedDate();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ungültiger Datumsbereich: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openDataFolder() {
        try {
            Path dir = Path.of("data").toAbsolutePath();
            Files.createDirectories(dir);
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(dir.toFile());
            } else {
                JOptionPane.showMessageDialog(this, "Pfad: " + dir, "Datenordner", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Konnte Datenordner nicht öffnen: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Simple combo model for date range
    static class DateComboModel extends DefaultComboBoxModel<LocalDate> {
        private LocalDate start;
        private LocalDate end;

        DateComboModel(LocalDate start, LocalDate end) {
            setRange(start, end);
        }

        public LocalDate getStart() { return start; }
        public LocalDate getEnd() { return end; }

        public void setRange(LocalDate start, LocalDate end) {
            this.start = start;
            this.end = end;
            removeAllElements();
            LocalDate d = start;
            while (!d.isAfter(end)) {
                addElement(d);
                d = d.plusDays(1);
            }
        }
    }
}
