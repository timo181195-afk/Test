package com.kalandertracker;

import com.kalandertracker.Models.*;

import javax.swing.table.AbstractTableModel;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.time.LocalDate;

public class ShiftTab extends JPanel {
    private final Shift shift;
    private final DataStore dataStore;

    private LocalDate currentDate;
    private Models.DayData dayData;
    private Models.ShiftData shiftData;

    private final PlanPanel planPanel;
    private final IstPanel istPanel;
    private final DowntimePanel downtimePanel;
    private final LiveChartPanel chartPanel;

    public ShiftTab(Shift shift, DataStore dataStore) {
        super(new BorderLayout());
        this.shift = shift;
        this.dataStore = dataStore;

        planPanel = new PlanPanel();
        istPanel = new IstPanel();
        downtimePanel = new DowntimePanel();
        chartPanel = new LiveChartPanel();

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Plan (Soll)", planPanel);
        tabs.addTab("Ist (Laufmeter)", istPanel);
        tabs.addTab("Stillstände", downtimePanel);
        tabs.addTab("Live-Chart", chartPanel);

        add(tabs, BorderLayout.CENTER);
    }

    public void load(LocalDate date) {
        this.currentDate = date;
        try {
            this.dayData = dataStore.loadDay(date);
        } catch (IOException e) {
            this.dayData = new Models.DayData();
        }
        this.shiftData = dayData.forShift(shift);

        planPanel.bind();
        istPanel.bind();
        downtimePanel.bind();
        chartPanel.bind();
    }

    private void save() {
        try {
            dataStore.saveDay(currentDate, dayData);
        } catch (IOException ignored) {}
    }

    // --- Panels
    private class PlanPanel extends JPanel {
        private final PlanTableModel model = new PlanTableModel();
        private final JTable table = new JTable(model);

        PlanPanel() {
            super(new BorderLayout());
            table.setFillsViewportHeight(true);
            add(new JScrollPane(table), BorderLayout.CENTER);

            JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JButton addJob = new JButton("+ Auftrag");
            JButton addStop = new JButton("+ Stillstand (geplant)");
            JButton remove = new JButton("Entfernen");
            JButton up = new JButton("▲");
            JButton down = new JButton("▼");
            JButton baseline = new JButton("Soll ab jetzt = Ist (Baseline)");

            addJob.addActionListener(e -> {
                PlanItem p = new PlanItem();
                p.type = PlanType.PRODUCE;
                p.meters = 11000;
                p.speedMpm = 60;
                shiftData.plan.add(p);
                model.fireTableDataChanged();
                save();
                chartPanel.repaint();
            });
            addStop.addActionListener(e -> {
                PlanItem p = new PlanItem();
                p.type = PlanType.DOWNTIME;
                p.durationMin = 10;
                p.downtimeReason = ReasonCatalog.REASONS.get(0);
                shiftData.plan.add(p);
                model.fireTableDataChanged();
                save();
                chartPanel.repaint();
            });
            remove.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r >= 0 && r < shiftData.plan.size()) {
                    shiftData.plan.remove(r);
                    model.fireTableDataChanged();
                    save();
                    chartPanel.repaint();
                }
            });
            up.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r > 0 && r < shiftData.plan.size()) {
                    var tmp = shiftData.plan.get(r);
                    shiftData.plan.set(r, shiftData.plan.get(r - 1));
                    shiftData.plan.set(r - 1, tmp);
                    model.fireTableDataChanged();
                    table.setRowSelectionInterval(r - 1, r - 1);
                    save();
                    chartPanel.repaint();
                }
            });
            down.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r >= 0 && r < shiftData.plan.size() - 1) {
                    var tmp = shiftData.plan.get(r);
                    shiftData.plan.set(r, shiftData.plan.get(r + 1));
                    shiftData.plan.set(r + 1, tmp);
                    model.fireTableDataChanged();
                    table.setRowSelectionInterval(r + 1, r + 1);
                    save();
                    chartPanel.repaint();
                }
            });
            baseline.addActionListener(e -> {
                if (shiftData.ist.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Kein IST-Wert vorhanden. Erst IST eintragen.");
                    return;
                }
                IstReading last = shiftData.ist.get(shiftData.ist.size() - 1);
                shiftData.baselineTimeEpochMs = last.timestampEpochMs;
                shiftData.baselineMeters = last.meterCumulative;
                save();
                chartPanel.repaint();
            });

            actions.add(addJob);
            actions.add(addStop);
            actions.add(remove);
            actions.add(up);
            actions.add(down);
            actions.add(baseline);

            add(actions, BorderLayout.NORTH);
        }

        void bind() {
            model.fireTableDataChanged();
        }

        private class PlanTableModel extends AbstractTableModel {
            private final String[] cols = new String[]{"Typ", "Meter", "m/min", "Dauer (min)", "Grund"};

            @Override public int getRowCount() { return shiftData == null ? 0 : shiftData.plan.size(); }
            @Override public int getColumnCount() { return cols.length; }
            @Override public String getColumnName(int column) { return cols[column]; }
            @Override public boolean isCellEditable(int rowIndex, int columnIndex) { return true; }

            @Override
            public Object getValueAt(int rowIndex, int columnIndex) {
                PlanItem p = shiftData.plan.get(rowIndex);
                return switch (columnIndex) {
                    case 0 -> p.type;
                    case 1 -> p.meters;
                    case 2 -> p.speedMpm;
                    case 3 -> p.durationMin;
                    case 4 -> p.downtimeReason;
                    default -> "";
                };
            }

            @Override
            public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
                PlanItem p = shiftData.plan.get(rowIndex);
                try {
                    switch (columnIndex) {
                        case 0 -> p.type = PlanType.valueOf(aValue.toString());
                        case 1 -> p.meters = Double.parseDouble(aValue.toString());
                        case 2 -> p.speedMpm = Double.parseDouble(aValue.toString());
                        case 3 -> p.durationMin = Long.parseLong(aValue.toString());
                        case 4 -> p.downtimeReason = aValue.toString();
                    }
                    // If produce and duration is 0, auto-calc from meters/speed for display
                    if (p.type == PlanType.PRODUCE) {
                        if (p.speedMpm > 0 && p.meters > 0) {
                            // durationMin is optional; if user leaves 0, we compute for chart
                        }
                    }
                    save();
                    chartPanel.repaint();
                } catch (Exception ignored) {
                }
                fireTableRowsUpdated(rowIndex, rowIndex);
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> PlanType.class;
                    case 1,2 -> Double.class;
                    case 3 -> Long.class;
                    default -> String.class;
                };
            }
        }
    }

    private class IstPanel extends JPanel {
        private final IstTableModel model = new IstTableModel();
        private final JTable table = new JTable(model);
        private final JTextField meterField = new JTextField(10);

        IstPanel() {
            super(new BorderLayout());
            table.setFillsViewportHeight(true);
            add(new JScrollPane(table), BorderLayout.CENTER);

            JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT));
            actions.add(new JLabel("IST Laufmeter (kumuliert seit Schichtstart):"));
            actions.add(meterField);
            JButton addNow = new JButton("IST eintragen (Zeit = jetzt)");
            JButton remove = new JButton("Entfernen");
            addNow.addActionListener(e -> {
                try {
                    double m = Double.parseDouble(meterField.getText().trim().replace(',', '.'));
                    long ts = System.currentTimeMillis();
                    shiftData.ist.add(new IstReading(ts, m));
                    shiftData.ist.sort((a,b) -> Long.compare(a.timestampEpochMs, b.timestampEpochMs));
                    model.fireTableDataChanged();
                    save();
                    chartPanel.repaint();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Ungültige Meterzahl");
                }
            });
            remove.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r >= 0 && r < shiftData.ist.size()) {
                    shiftData.ist.remove(r);
                    model.fireTableDataChanged();
                    save();
                    chartPanel.repaint();
                }
            });

            actions.add(addNow);
            actions.add(remove);
            add(actions, BorderLayout.NORTH);
        }

        void bind() { model.fireTableDataChanged(); }

        private class IstTableModel extends AbstractTableModel {
            private final String[] cols = new String[]{"Zeit (epoch ms)", "Meter (kumuliert)"};
            @Override public int getRowCount() { return shiftData == null ? 0 : shiftData.ist.size(); }
            @Override public int getColumnCount() { return cols.length; }
            @Override public String getColumnName(int column) { return cols[column]; }
            @Override public boolean isCellEditable(int r, int c) { return c == 1; }

            @Override
            public Object getValueAt(int rowIndex, int columnIndex) {
                IstReading r = shiftData.ist.get(rowIndex);
                return columnIndex == 0 ? r.timestampEpochMs : r.meterCumulative;
            }

            @Override
            public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
                try {
                    if (columnIndex == 1) {
                        shiftData.ist.get(rowIndex).meterCumulative = Double.parseDouble(aValue.toString());
                        save();
                        chartPanel.repaint();
                    }
                } catch (Exception ignored) {}
                fireTableRowsUpdated(rowIndex, rowIndex);
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 0 ? Long.class : Double.class;
            }
        }
    }

    private class DowntimePanel extends JPanel {
        private final DowntimeTableModel model = new DowntimeTableModel();
        private final JTable table = new JTable(model);
        private final JComboBox<String> reasonCombo = new JComboBox<>(ReasonCatalog.REASONS.toArray(new String[0]));
        private final JTextArea description = new JTextArea(3, 40);
        private Downtime active;

        DowntimePanel() {
            super(new BorderLayout());
            table.setFillsViewportHeight(true);
            add(new JScrollPane(table), BorderLayout.CENTER);

            JPanel top = new JPanel(new BorderLayout());
            JPanel line1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
            JButton start = new JButton("START (jetzt)");
            JButton end = new JButton("ENDE (jetzt)");
            JButton remove = new JButton("Entfernen");

            line1.add(new JLabel("Grund:"));
            line1.add(reasonCombo);
            line1.add(start);
            line1.add(end);
            line1.add(remove);

            top.add(line1, BorderLayout.NORTH);

            description.setLineWrap(true);
            description.setWrapStyleWord(true);
            JPanel line2 = new JPanel(new BorderLayout());
            line2.add(new JLabel("Beschreibung (frei):"), BorderLayout.NORTH);
            line2.add(new JScrollPane(description), BorderLayout.CENTER);
            top.add(line2, BorderLayout.CENTER);

            start.addActionListener(e -> {
                if (active != null && active.isOpen()) {
                    JOptionPane.showMessageDialog(this, "Es läuft bereits ein Stillstand. Erst ENDE drücken.");
                    return;
                }
                String reason = (String) reasonCombo.getSelectedItem();
                String desc = description.getText();
                active = new Downtime(System.currentTimeMillis(), reason == null ? "" : reason, desc == null ? "" : desc);
                shiftData.downtimes.add(active);
                model.fireTableDataChanged();
                save();
                chartPanel.repaint();
            });

            end.addActionListener(e -> {
                if (active == null || !active.isOpen()) {
                    // try to end the last open one
                    for (int i = shiftData.downtimes.size()-1; i >= 0; i--) {
                        Downtime d = shiftData.downtimes.get(i);
                        if (d.isOpen()) { active = d; break; }
                    }
                }
                if (active == null || !active.isOpen()) {
                    JOptionPane.showMessageDialog(this, "Kein laufender Stillstand.");
                    return;
                }
                active.endEpochMs = System.currentTimeMillis();
                model.fireTableDataChanged();
                save();
                chartPanel.repaint();
            });

            remove.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r >= 0 && r < shiftData.downtimes.size()) {
                    Downtime removed = shiftData.downtimes.remove(r);
                    if (removed == active) active = null;
                    model.fireTableDataChanged();
                    save();
                    chartPanel.repaint();
                }
            });

            add(top, BorderLayout.NORTH);
        }

        void bind() {
            active = null;
            model.fireTableDataChanged();
        }

        private class DowntimeTableModel extends AbstractTableModel {
            private final String[] cols = new String[]{"Start(ms)", "Ende(ms)", "Grund", "Beschreibung"};
            @Override public int getRowCount() { return shiftData == null ? 0 : shiftData.downtimes.size(); }
            @Override public int getColumnCount() { return cols.length; }
            @Override public String getColumnName(int column) { return cols[column]; }
            @Override public boolean isCellEditable(int r, int c) { return c >= 2; }

            @Override
            public Object getValueAt(int rowIndex, int columnIndex) {
                Downtime d = shiftData.downtimes.get(rowIndex);
                return switch (columnIndex) {
                    case 0 -> d.startEpochMs;
                    case 1 -> d.endEpochMs;
                    case 2 -> d.reason;
                    case 3 -> d.description;
                    default -> "";
                };
            }

            @Override
            public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
                Downtime d = shiftData.downtimes.get(rowIndex);
                if (columnIndex == 2) d.reason = aValue.toString();
                if (columnIndex == 3) d.description = aValue.toString();
                save();
                fireTableRowsUpdated(rowIndex, rowIndex);
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0,1 -> Long.class;
                    default -> String.class;
                };
            }
        }
    }

    private class LiveChartPanel extends JPanel {
        private final Timer timer;

        LiveChartPanel() {
            setLayout(new BorderLayout());
            ChartCanvas canvas = new ChartCanvas();
            add(canvas, BorderLayout.CENTER);

            timer = new Timer(1000, e -> canvas.repaint());
            timer.start();
        }

        void bind() {
            repaint();
        }

        private class ChartCanvas extends JPanel {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (shiftData == null || currentDate == null) return;
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                ChartRenderer.renderShiftChart(g2, getWidth(), getHeight(), currentDate, shift, shiftData);
            }
        }
    }
}
