package com.kalandertracker;

import com.kalandertracker.Models.*;

import java.io.IOException;
import java.nio.file.Path;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class PDFExporter {
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public static void exportDayReport(Path out, LocalDate date, Models.DayData day) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("Kalander Soll/Ist Report");
        lines.add("Datum: " + date.format(DATE_FMT));
        lines.add("");

        for (Shift shift : Shift.values()) {
            ShiftData sd = day.forShift(shift);
            lines.add("Schicht: " + shift.label + " (" + shift.start + " - " + shift.end + ")");

            double planEnd = Metrics.planEndMeters(sd);
            double istEnd = Metrics.istEndMeters(sd);
            long downtimeMin = Metrics.totalDowntimeMinutes(sd);

            lines.add("  Soll Endstand: " + fmt0(planEnd) + " m");
            lines.add("  Ist  Endstand: " + fmt0(istEnd) + " m");
            lines.add("  Delta:        " + fmt0(istEnd - planEnd) + " m");
            lines.add("  Stillstand:   " + downtimeMin + " min");

            if (sd.baselineTimeEpochMs > 0) {
                lines.add("  Baseline (Soll ab jetzt = Ist): " + Instant.ofEpochMilli(sd.baselineTimeEpochMs) + ", " + fmt0(sd.baselineMeters) + " m");
            }

            if (!sd.downtimes.isEmpty()) {
                lines.add("  Stillstände:");
                for (Downtime d : sd.downtimes) {
                    long dur = Metrics.downtimeMinutes(d);
                    lines.add("    - " + safe(d.reason) + " | " + dur + " min");
                    if (d.description != null && !d.description.isBlank()) {
                        for (String part : d.description.split("\\n")) {
                            lines.add("        " + part);
                        }
                    }
                }
            }
            lines.add("");
        }

        SimplePDF.writeTextPdf(out, lines);
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }

    private static String fmt0(double v) {
        return String.format(java.util.Locale.ROOT, "%.0f", v);
    }
}
