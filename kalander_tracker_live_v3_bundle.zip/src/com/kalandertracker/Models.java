package com.kalandertracker;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class Models {
    public enum PlanType { PRODUCE, DOWNTIME }

    public static class PlanItem {
        public PlanType type = PlanType.PRODUCE;
        public double meters = 0.0;          // for produce
        public double speedMpm = 0.0;        // for produce
        public long durationMin = 0;         // for downtime (and optionally produce override)
        public String downtimeReason = "";   // for downtime
    }

    public static class IstReading {
        public long timestampEpochMs;
        public double meterCumulative;

        public IstReading(long ts, double m) {
            this.timestampEpochMs = ts;
            this.meterCumulative = m;
        }
    }

    public static class Downtime {
        public long startEpochMs;
        public long endEpochMs; // 0 if open
        public String reason;
        public String description;

        public Downtime(long startEpochMs, String reason, String description) {
            this.startEpochMs = startEpochMs;
            this.reason = reason;
            this.description = description;
            this.endEpochMs = 0;
        }

        public boolean isOpen() {
            return endEpochMs <= 0;
        }
    }

    public static class ShiftData {
        public List<PlanItem> plan = new ArrayList<>();
        public List<IstReading> ist = new ArrayList<>();
        public List<Downtime> downtimes = new ArrayList<>();

        // Baseline: optional reset inside the shift ("Soll ab jetzt auf Ist")
        public long baselineTimeEpochMs = 0;
        public double baselineMeters = 0.0;

        public ShiftData() {}
    }

    public static class DayData {
        public ShiftData early = new ShiftData();
        public ShiftData late = new ShiftData();
        public ShiftData night = new ShiftData();

        public ShiftData forShift(Shift shift) {
            return switch (shift) {
                case EARLY -> early;
                case LATE -> late;
                case NIGHT -> night;
            };
        }
    }
}
