package com.kalandertracker;

import com.kalandertracker.Models.*;

import java.awt.*;
import java.time.*;
import java.util.ArrayList;
import java.util.List;

public class ChartRenderer {

    private static class PointD {
        final double x;
        final double y;
        PointD(double x, double y) { this.x = x; this.y = y; }
    }

    public static void renderShiftChart(Graphics2D g2, int w, int h, LocalDate date, Shift shift, ShiftData sd) {
        int marginL = 60;
        int marginR = 20;
        int marginT = 20;
        int marginB = 50;

        int plotW = Math.max(1, w - marginL - marginR);
        int plotH = Math.max(1, h - marginT - marginB);

        // Background
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, w, h);

        // Axes
        g2.setColor(Color.DARK_GRAY);
        g2.drawRect(marginL, marginT, plotW, plotH);

        ZoneId zone = ZoneId.systemDefault();
        long shiftStart = shift.startDateTime(date, zone).toInstant().toEpochMilli();
        long shiftEnd = shift.endDateTime(date, zone).toInstant().toEpochMilli();

        // Apply baseline if set (inside-shift reset)
        long baselineTime = sd.baselineTimeEpochMs > 0 ? sd.baselineTimeEpochMs : shiftStart;
        double baselineMeters = sd.baselineTimeEpochMs > 0 ? sd.baselineMeters : 0.0;

        // Build plan curve
        List<PointD> plan = buildPlanCurve(sd, baselineTime, baselineMeters, shiftEnd);
        // Build ist curve
        List<PointD> ist = buildIstCurve(sd, baselineTime, baselineMeters);

        double maxY = Math.max(maxY(plan), maxY(ist));
        if (maxY < 1) maxY = 1;

        // Grid + labels
        drawTimeGrid(g2, marginL, marginT, plotW, plotH, shiftStart, shiftEnd);
        drawMeterGrid(g2, marginL, marginT, plotW, plotH, maxY);

        // Plot lines
        g2.setStroke(new BasicStroke(2f));
        g2.setColor(new Color(30, 90, 200)); // plan
        drawPolyline(g2, plan, marginL, marginT, plotW, plotH, baselineTime, shiftEnd, maxY);

        g2.setColor(new Color(200, 70, 30)); // ist
        drawPolyline(g2, ist, marginL, marginT, plotW, plotH, baselineTime, shiftEnd, maxY);

        // Legend
        g2.setColor(Color.BLACK);
        g2.drawString("Plan (Soll)", marginL + 10, marginT + 15);
        g2.drawString("Ist", marginL + 120, marginT + 15);

        // Title
        g2.drawString("Live Verlauf: " + date + " | " + shift.label + " (Baseline-Reset optional)", marginL, h - 10);

        // Now marker
        long now = System.currentTimeMillis();
        if (now >= baselineTime && now <= shiftEnd) {
            int x = marginL + (int) ((now - baselineTime) * 1.0 / (shiftEnd - baselineTime) * plotW);
            g2.setColor(new Color(0,0,0,80));
            g2.drawLine(x, marginT, x, marginT + plotH);
        }
    }

    private static List<PointD> buildPlanCurve(ShiftData sd, long baselineTime, double baselineMeters, long shiftEnd) {
        List<PointD> pts = new ArrayList<>();
        pts.add(new PointD(baselineTime, 0));
        long t = baselineTime;
        double m = baselineMeters;

        for (PlanItem p : sd.plan) {
            if (t >= shiftEnd) break;
            if (p.type == PlanType.DOWNTIME) {
                long durMin = Math.max(0, p.durationMin);
                long dt = durMin * 60000L;
                long t2 = Math.min(shiftEnd, t + dt);
                // flat line
                pts.add(new PointD(t2, m - baselineMeters));
                t = t2;
            } else {
                double meters = Math.max(0, p.meters);
                double speed = p.speedMpm;
                long durMin;
                if (p.durationMin > 0) durMin = p.durationMin;
                else if (speed > 0) durMin = (long) Math.ceil(meters / speed);
                else durMin = 0;

                long dt = durMin * 60000L;
                long t2 = Math.min(shiftEnd, t + dt);

                // linear ramp
                m += meters;
                pts.add(new PointD(t2, m - baselineMeters));
                t = t2;
            }
        }
        // extend to shift end
        if (pts.get(pts.size()-1).x < shiftEnd) {
            pts.add(new PointD(shiftEnd, pts.get(pts.size()-1).y));
        }
        return pts;
    }

    private static List<PointD> buildIstCurve(ShiftData sd, long baselineTime, double baselineMeters) {
        List<PointD> pts = new ArrayList<>();
        pts.add(new PointD(baselineTime, 0));
        for (IstReading r : sd.ist) {
            if (r.timestampEpochMs < baselineTime) continue;
            pts.add(new PointD(r.timestampEpochMs, Math.max(0, r.meterCumulative - baselineMeters)));
        }
        return pts;
    }

    private static void drawPolyline(Graphics2D g2, List<PointD> pts, int x0, int y0, int w, int h, long tMin, long tMax, double yMax) {
        if (pts.size() < 2) return;
        int prevX = -1, prevY = -1;
        for (PointD p : pts) {
            double tx = (p.x - tMin) * 1.0 / Math.max(1, (tMax - tMin));
            double ty = p.y / yMax;
            int x = x0 + (int) Math.round(tx * w);
            int y = y0 + h - (int) Math.round(ty * h);
            if (prevX >= 0) g2.drawLine(prevX, prevY, x, y);
            prevX = x; prevY = y;
        }
    }

    private static void drawTimeGrid(Graphics2D g2, int x0, int y0, int w, int h, long tStart, long tEnd) {
        g2.setStroke(new BasicStroke(1f));
        g2.setColor(new Color(0,0,0,30));

        int segments = 8; // 8h
        for (int i=0;i<=segments;i++) {
            int x = x0 + (int) Math.round(i * 1.0 / segments * w);
            g2.drawLine(x, y0, x, y0 + h);
        }
        g2.setColor(Color.DARK_GRAY);
        g2.drawString("Zeit →", x0 + w - 40, y0 + h + 35);
    }

    private static void drawMeterGrid(Graphics2D g2, int x0, int y0, int w, int h, double maxY) {
        g2.setStroke(new BasicStroke(1f));
        g2.setColor(new Color(0,0,0,30));
        int lines = 5;
        for (int i=0;i<=lines;i++) {
            int y = y0 + (int) Math.round(i * 1.0 / lines * h);
            g2.drawLine(x0, y, x0 + w, y);
        }
        g2.setColor(Color.DARK_GRAY);
        g2.drawString("Meter ↑", 10, y0 + 15);
        g2.drawString(String.format(java.util.Locale.ROOT, "0"), x0 - 35, y0 + h);
        g2.drawString(String.format(java.util.Locale.ROOT, "%.0f", maxY), x0 - 45, y0 + 10);
    }

    private static double maxY(List<PointD> pts) {
        double m = 0;
        for (PointD p : pts) m = Math.max(m, p.y);
        return m;
    }
}
