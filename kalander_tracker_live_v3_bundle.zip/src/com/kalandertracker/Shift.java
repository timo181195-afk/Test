package com.kalandertracker;

import java.time.*;

public enum Shift {
    EARLY("Früh", LocalTime.of(6,0), LocalTime.of(14,0)),
    LATE("Spät", LocalTime.of(14,0), LocalTime.of(22,0)),
    NIGHT("Nacht", LocalTime.of(22,0), LocalTime.of(6,0));

    public final String label;
    public final LocalTime start;
    public final LocalTime end;

    Shift(String label, LocalTime start, LocalTime end) {
        this.label = label;
        this.start = start;
        this.end = end;
    }

    public Duration duration() {
        if (!end.isAfter(start)) {
            return Duration.ofHours(8); // night crosses midnight; fixed 8h
        }
        return Duration.between(start, end);
    }

    public ZonedDateTime startDateTime(LocalDate date, ZoneId zone) {
        return ZonedDateTime.of(date, start, zone);
    }

    public ZonedDateTime endDateTime(LocalDate date, ZoneId zone) {
        if (this == NIGHT) {
            return ZonedDateTime.of(date.plusDays(1), end, zone);
        }
        return ZonedDateTime.of(date, end, zone);
    }
}
