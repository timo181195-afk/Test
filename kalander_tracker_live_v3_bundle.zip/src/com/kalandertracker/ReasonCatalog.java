package com.kalandertracker;

import java.util.List;

public class ReasonCatalog {
    public static final List<String> REASONS = List.of(
            "Rüsten – Prägewalze wechseln",
            "Rüsten – Gummiwalze wechseln",
            "Ausmustern",
            "Ausmustern mit Sonderbehandlung",
            "Neue Ausmusterung",
            "Produktionsmittel nicht vorhanden",
            "Produktionsmittel fehlerhaft",
            "Reinigen",
            "Reparatur an Kalander",
            "Reparatur an Plastikifizierungseinheit",
            "Reparatur an Aufrollung",
            "Richtgeschwindigkeitsabweichung",
            "Richtgeschwindigkeit wegen Personalengpass",
            "Richtgeschwindigkeit qualitätsbedingt"
    );
}
