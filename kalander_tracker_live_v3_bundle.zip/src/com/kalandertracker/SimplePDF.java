package com.kalandertracker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal PDF writer for simple text pages (no external libraries).
 * Supports one A4 page, Helvetica, left-aligned, basic line wrapping.
 */
public class SimplePDF {
    public static void writeTextPdf(Path out, List<String> lines) throws IOException {
        // Basic wrapping: limit ~100 chars per line
        List<String> wrapped = new ArrayList<>();
        for (String l : lines) {
            if (l == null) {
                wrapped.add("");
                continue;
            }
            String s = l;
            while (s.length() > 100) {
                int cut = s.lastIndexOf(' ', 100);
                if (cut <= 0) cut = 100;
                wrapped.add(s.substring(0, cut));
                s = s.substring(cut).trim();
            }
            wrapped.add(s);
        }

        String content = buildContentStream(wrapped);
        byte[] contentBytes = content.getBytes(StandardCharsets.ISO_8859_1);

        List<byte[]> objects = new ArrayList<>();

        // 1: Catalog
        objects.add(str("<< /Type /Catalog /Pages 2 0 R >>"));
        // 2: Pages
        objects.add(str("<< /Type /Pages /Kids [3 0 R] /Count 1 >>"));
        // 3: Page
        objects.add(str("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>"));
        // 4: Font
        objects.add(str("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"));
        // 5: Content stream
        String streamObj = "<< /Length " + contentBytes.length + " >>\nstream\n" + content + "\nendstream";
        objects.add(streamObj.getBytes(StandardCharsets.ISO_8859_1));

        // Build xref
        StringBuilder pdf = new StringBuilder();
        pdf.append("%PDF-1.4\n");
        List<Integer> offsets = new ArrayList<>();
        offsets.add(0); // object 0

        int cursor = pdf.toString().getBytes(StandardCharsets.ISO_8859_1).length;
        for (int i = 0; i < objects.size(); i++) {
            offsets.add(cursor);
            String header = (i + 1) + " 0 obj\n";
            pdf.append(header);
            pdf.append(new String(objects.get(i), StandardCharsets.ISO_8859_1));
            pdf.append("\nendobj\n");
            cursor = pdf.toString().getBytes(StandardCharsets.ISO_8859_1).length;
        }

        int xrefPos = cursor;
        pdf.append("xref\n");
        pdf.append("0 ").append(objects.size() + 1).append("\n");
        pdf.append("0000000000 65535 f \n");
        for (int i = 1; i < offsets.size(); i++) {
            pdf.append(String.format(java.util.Locale.ROOT, "%010d 00000 n \n", offsets.get(i)));
        }
        pdf.append("trailer\n");
        pdf.append("<< /Size ").append(objects.size() + 1).append(" /Root 1 0 R >>\n");
        pdf.append("startxref\n");
        pdf.append(xrefPos).append("\n");
        pdf.append("%%EOF\n");

        Files.write(out, pdf.toString().getBytes(StandardCharsets.ISO_8859_1));
    }

    private static byte[] str(String s) {
        return s.getBytes(StandardCharsets.ISO_8859_1);
    }

    private static String buildContentStream(List<String> lines) {
        // 12pt font, start near top-left
        StringBuilder sb = new StringBuilder();
        sb.append("BT\n");
        sb.append("/F1 11 Tf\n");
        sb.append("50 800 Td\n");

        int lineHeight = 14;
        int y = 800;
        for (String line : lines) {
            if (y < 60) break; // single page limitation
            String safe = escapePdfText(line);
            sb.append("(").append(safe).append(") Tj\n");
            sb.append("0 -").append(lineHeight).append(" Td\n");
            y -= lineHeight;
        }
        sb.append("ET");
        return sb.toString();
    }

    private static String escapePdfText(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("(", "\\(")
                .replace(")", "\\)")
                .replace("\r", "")
                .replace("\n", " ");
    }
}
